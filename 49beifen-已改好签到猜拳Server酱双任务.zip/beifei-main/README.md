# beifei  
##### 参数  
| name | Value |  
| --- | --- |  
| UNICOM_USER | 手机号 |  
| UNICOM_PASSWORD | 服务密码 |  
| UNICOM_APPID | appid |  
| UNICOM_USER | 手机号2 |  
| UNICOM_PASSWORD | 服务密码2 |  
| UNICOM_APPID | appid2 |  
| NOTIFY_SCKEY | Server酱SendKey（可选） |
